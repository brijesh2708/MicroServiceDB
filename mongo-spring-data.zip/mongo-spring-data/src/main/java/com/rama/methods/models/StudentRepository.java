package com.rama.methods.models;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends MongoRepository<Student, String>{
	
	public Student findByName (String name);
	public void deleteByname(String name);
	public Student save(Student student);

}
